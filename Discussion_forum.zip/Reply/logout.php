<?php
	
	unset($_SESSION['role']);
	unset($_SESSION['IS_LOGIN']);
	header("location:login.php");
	die();
?>